#define BUFFER_SIZE 42 /* This should suffice as all ciphertexts are 42 characters */

#include <iostream>
#include <fstream>
#include <string>
#include <assert.h>

using namespace std;

/*
     * Reads all bytes from a file pointed to by path into the given buffer. Make sure your buffer size is big enough!
     * 
     * Returns true on success, or false if the file pointed to by path could not be opened.
     */ 
bool readBytes(char *buffer, string path) {
    ifstream fin;
    fin.open(path, ios::binary);
    if (!fin.is_open()) {
        printf("The path you specified is not valid: %s\n", path.c_str());
        return false;
    }

    fin.read(buffer, BUFFER_SIZE);
    fin.close();

    return true;
}

int main() {
    string filename = "../p1/p1_c1_plain"; /* The .. means to go into the parent directory */

    char buffer[BUFFER_SIZE];
    if (!readBytes(buffer, filename)) return -1;

    cout << "------------------------------------------------------------------------------------------" << endl;
    cout << "Example: Read all bytes of a ciphertext into a 42-byte buffer, starting at the beginning" << endl;
    cout << "------------------------------------------------------------------------------------------" << endl;
    for (int i = 0; i < BUFFER_SIZE; i++) {
        printf("Byte %d: %d\n", i, buffer[i] & 0xff); // prints the ASCII codes of all input
    }

    // You can then convert to a string if you want (though we don't recommend it, since you will have to worry
    // about the null-terminator) and there isn't any particular need to do so
    cout << "\n------------------------------------------------------------------------------------------" << endl;
    cout << "You can then convert to a string if you want:" << endl;
    cout << "------------------------------------------------------------------------------------------" << endl;

    string stringVersion(buffer, BUFFER_SIZE);
    cout << stringVersion << endl << endl;

    // You can also convert back into the char array like so:
    char *bufferCopy = &stringVersion[0];
    for (int i = 0; i < BUFFER_SIZE; i++) {
        assert(bufferCopy[i] == buffer[i]); // This won't fail; it's just a sanity check
    }
}
