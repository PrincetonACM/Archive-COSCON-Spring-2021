# Reads bytes from file pointed to by path and returns an extended ASCII-encoded 
# string with the data in it
def read_bytes(path):
    with open(path, 'rb') as infile: cipher = infile.read().decode('latin-1')
    return cipher

if __name__ == '__main__':
    filename = "../p1/p1_c1_plain" # The .. means to go into the parent directory
    for i, c in enumerate(read_bytes(filename)):
        print("Byte {}: {}".format(i, ord(c))) # Prints bytes ASCII-encoded
