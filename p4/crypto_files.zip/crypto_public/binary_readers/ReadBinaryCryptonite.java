import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Base64;

public class ReadBinaryCryptonite {

    /*
     * Reads all bytes from a file pointed to by path into the given buffer. Make sure your buffer size is big enough!
     * 
     * Returns true on success, or false if an exception was thrown.
     */ 
    private static boolean readBytes(byte[] buffer, String path) {
        try{
            InputStream input = new FileInputStream(path);
            input.read(buffer);
            input.close();
        }
        catch (FileNotFoundException e) {
            System.out.printf("The path you specified was not found: %s/%s\n", 
                                            System.getProperty("user.dir"), path);
            return false;
        }
        catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }

    public static void main(String[] args) {
        final int BUFFER_SIZE = 42; // This will suffice as each ciphertext is 42 bytes
        String filename = "../p1/p1_c1_plain"; // The .. means to go into the parent directory

        // Example: Read all bytes of a ciphertext into a 42-byte buffer, starting at the beginning
        byte[] buffer = new byte[BUFFER_SIZE];
        if (!readBytes(buffer, filename)) return; // Attempt to read in the bytes

        System.out.println("------------------------------------------------------------------------------------------");
        System.out.println("Example: Read all bytes of a ciphertext into a 42-byte buffer, starting at the beginning");
        System.out.println("------------------------------------------------------------------------------------------");
        for (int i = 0; i < BUFFER_SIZE; i++) {
            System.out.printf("Byte %d: %d\n", i, buffer[i] & 0xff); // prints the ASCII codes of all input
        }

        // You can then convert to a string if you want
        System.out.println("\n------------------------------------------------------------------------------------------");
        System.out.println("You can then convert to a string if you want:");
        System.out.println("------------------------------------------------------------------------------------------");
        String stringVersion = Base64.getEncoder().encodeToString(buffer);
        System.out.println(stringVersion + "\n");

        // And back to the byte array
        byte[] byteVersion = Base64.getDecoder().decode(stringVersion);
        for (int i = 0; i < BUFFER_SIZE; i++) {
            assert byteVersion[i] == buffer[i]: "There was an error"; // This will not happen; it's just a check
        }
    }
}
